<template>
  <main class="lesson main">
    <section class="section1">
      <div class="flex_col">
        <div class="flex_col1">
          <div class="flex_col2">
            <img class="image4" src="/assets/spicy_icon_graphic.png" alt="alt text" />
            <div class="flex_row">
              <h1 class="hero_title2">Food</h1>
              <h1 class="hero_title3">Hub</h1>
            </div>
          </div>
          <h1 class="hero_title">Кулинарные мастер-классы</h1>
        </div>
        <div class="flex_row1">
          <div class="flex_col3">
            <h5 class="highlight_box">
              <span class="highlight"
                ><span class="highlight_span0">От </span><span class="highlight_span1">классических рецептов</span
                ><span class="highlight_span2"> до </span><span class="highlight_span3">кулинарных экспериментов</span
                ><span class="highlight_span4">
                  - каждый урок станет увлекательным путешествием по миру высокой кухни</span
                ></span
              >
            </h5>
            <h5 class="highlight1">
              Наши мастер-классы по приготовлению блюд - это захватывающее погружение в мир кулинарных вкусов и навыков.
              Опытные шеф-повара приветствуют вас в уютной атмосфере, где вы узнаете секреты приготовления разнообразных
              блюд из различных кухонь мира. От итальянской пасты до азиатских деликатесов, от выпечки до десертов -
              каждый урок наполнен вдохновением, интерактивным обучением и удовольствием от творчества на кухне.
              Присоединяйтесь к нам и откройте для себя новые гастрономические горизонты!
            </h5>
          </div>
          <img class="image3" src="/assets/grilled_vegetables_on_plate.png" alt="alt text" />
        </div>
      </div>
    </section>

    <section class="section2">
      <div class="flex_col4">
        <h1 class="hero_title1_box">
          <span class="hero_title1"
            ><span class="hero_title1_span0">Наши </span><span class="hero_title1_span1">премущества</span></span
          >
        </h1>
        <div class="flex_col5">
          <div class="flex_row2">
            <div class="flex_col6">
              <img class="image" src="/assets/smiling_chef_in_kitchen.png" alt="alt text" />
              <h2 class="medium_title_box">
                <span class="medium_title"
                  ><span class="medium_title_span0">Опытные инструкторы: <br /></span
                  ><span class="medium_title_span1"
                    >Все наши мастер-классы проводят опытные шеф-повара с богатым опытом работы в кулинарии. Они будут
                    делиться с вами своими знаниями, техниками и секретами, помогая вам стать настоящим профессионалом
                    на кухне.</span
                  ></span
                >
              </h2>
            </div>
            <div class="flex_col6">
              <img class="image" src="/assets/chef_cooking_during_class.png" alt="alt text" />
              <h2 class="medium_title_box">
                <span class="medium_title"
                  ><span class="medium_title_span0">Разнообразие уроков: <br /></span
                  ><span class="medium_title_span1"
                    >Наши мастер-классы предлагают широкий спектр тематик, от классических рецептов до экзотических
                    кулинарных приключений. Вы сможете выбрать тот урок, который соответствует вашим вкусам и
                    интересам.</span
                  ></span
                >
              </h2>
            </div>
          </div>
          <div class="flex_row3">
            <div class="flex_col7">
              <img class="image1" src="/assets/ingredients_for_burger_preparation.png" alt="alt text" />
              <h2 class="medium_title_box1">
                <span class="medium_title"
                  ><span class="medium_title_span0">Качество ингредиентов: <br /></span
                  ><span class="medium_title_span1"
                    >Мы используем только самые свежие и качественные ингредиенты для приготовления блюд. Это
                    гарантирует не только отличный вкус, но и максимальную полезность каждого приготовленного
                    блюда.</span
                  ></span
                >
              </h2>
            </div>
            <div class="flex_col8">
              <img class="image2" src="/assets/restaurant_team_meeting.png" alt="alt text" />
              <h2 class="medium_title_box2">
                <span class="medium_title"
                  ><span class="medium_title_span0">Вдохновение и удовольствие: <br /></span
                  ><span class="medium_title_span1"
                    >Вы сможете провести время с удовольствием, наслаждаясь процессом приготовления и результатом вашего
                    творчества.</span
                  ></span
                >
              </h2>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section3">
      <div class="flex_col9">
        <h1 class="hero_title4">Мы предоставляем широкий спектр кулинарных мастер-классов</h1>
        <div class="flex_col10">
          <div class="content_box11">
            <div class="content_box4">
              <div class="flex_col11">
                <h1 class="title">&quot;Итальянская кухня во всей красе&quot;</h1>
                <h2 class="medium_title1">
                  Участники узнают секреты приготовления классических итальянских блюд, таких как паста карбонара, пицца
                  Маргарита, оливковое масло и многое другое.
                </h2>
              </div>
            </div>
          </div>
          <div class="content_box10">
            <div class="content_box5">
              <div class="flex_col12">
                <h1 class="title1">&quot;Азиатские вкусовые сенсации&quot;</h1>
                <h2 class="medium_title2">
                  В рамках этого урока участники познакомятся с техникой приготовления блюд из различных азиатских
                  кухонь, включая суши, вок и тайские карри.
                </h2>
              </div>
            </div>
          </div>
          <div class="content_box9">
            <div class="content_box6">
              <div class="flex_col13">
                <h1 class="title1">&quot;Десерты для гурманов&quot;</h1>
                <h2 class="medium_title3">
                  На этом уроке участники научатся создавать изысканные десерты, такие как крем-брюле, шоколадные тарты,
                  фруктовые муссы и многое другое, радуя себя и своих близких сладким удовольствием.<br />
                </h2>
              </div>
            </div>
          </div>
          <div class="content_box8">
            <div class="content_box7">
              <div class="flex_col14">
                <h1 class="title">&quot;Шедевры мировой выпечки&quot;</h1>
                <h2 class="medium_title4">
                  На этом уроке участники научатся готовить разнообразные виды хлеба, круассаны, пироги и другие
                  выпечные изделия, погружаясь в мир теста и дрожжей.
                </h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section4">
      <div class="section41">
        <div class="flex_row4">
          <h1 class="hero_title11_box">
            <span class="hero_title11"
              ><span class="hero_title11_span0">Остались вопросы?<br /></span
              ><span class="hero_title11_span1">Вы можете задать их нам через Telegram!</span></span
            >
          </h1>
          <div class="content_box3">
            <div class="flex_col15">
              <div class="content_box"><h3 class="subtitle">Введите ваш вопрос</h3></div>
              <div class="content_box"><h3 class="subtitle1">Ваше имя</h3></div>
              <div class="content_box">
                <h3 class="subtitle2_box">
                  <span class="subtitle2"
                    ><span class="subtitle2_span0">+7 </span><span class="subtitle2_span1">(___)___-____</span></span
                  >
                </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>

<style scoped lang="scss">
@import 'Lesson.scss';
</style>
