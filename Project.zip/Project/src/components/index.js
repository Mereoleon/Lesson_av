import Lesson from './Lesson.vue';

export default { Lesson };
