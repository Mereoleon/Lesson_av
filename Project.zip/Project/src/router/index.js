import { createRouter, createWebHistory } from 'vue-router';
import ScreenList from '../ScreenList.vue';
import Lesson from '../components/Lesson.vue';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'screenList',
      component: ScreenList,
    },
    {
      path: '/Lesson',
      name: 'Lesson',
      component: Lesson,
    },
  ],
});

export default router;
