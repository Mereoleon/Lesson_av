<script setup>
import { useRoute, RouterView } from 'vue-router';
import { watch } from "vue";
import Sticky from 'sticky-js';

let sticky;
const route = useRoute();

watch(
    route,
    async () => {
      if (sticky) {
        sticky.destroy();
      }
      sticky = new Sticky('.sticky-effect');
    }
);

</script>

<template>
  <RouterView/>
</template>

