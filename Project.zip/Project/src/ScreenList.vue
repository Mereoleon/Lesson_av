<script setup>
import { RouterLink } from 'vue-router';
</script>

<template>
  <div>
    pxCode Screen List: <br />
    <RouterLink to="/Lesson">Lesson</RouterLink>
  </div>
</template>
